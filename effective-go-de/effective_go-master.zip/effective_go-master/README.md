# effective_go
Zusätzliches Material zum Udemy Kurs
