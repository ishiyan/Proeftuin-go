package beispiel

// ExportedVar is a example
var ExportedVar = 0

var unexportedVar = 5
