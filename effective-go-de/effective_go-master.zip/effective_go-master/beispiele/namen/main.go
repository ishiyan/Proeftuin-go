package main

import (
	"github.com/gokurs/effective_go/beispiele/namen/beispiel"
)

func main() {
	beispiel.ExportedVar = 2
	// beispiel.unexportedVar = 4
}
