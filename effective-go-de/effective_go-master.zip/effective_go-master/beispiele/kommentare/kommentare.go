/*
Package kommentare is just an example for the
udemy course, how you should comment your code
*/
package kommentare

// MyFunc is another example how to comment a
// function
func MyFunc() {
	// mach was
}
