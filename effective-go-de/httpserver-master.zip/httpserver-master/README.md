# httpserver
Zusätzliche Materialien zum Kurs http Server mit Go
