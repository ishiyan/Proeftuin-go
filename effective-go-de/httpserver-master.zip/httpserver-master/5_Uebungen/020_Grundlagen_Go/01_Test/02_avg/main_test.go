package main

import "testing"

func TestAvg(t *testing.T) {
	/*
		Dein Test kommt hier rein.
	*/
}
