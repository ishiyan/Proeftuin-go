package main

func main() {

}

/*
	1) Erstelle sinnvolle Tests um die Funktion avg zu testen.
	2) Editiere avg, damit wir ein PASS bekommen
*/

// avg berechnet den Durchschnitt aus den integers und gib diesen als
// Ganzzahl (int) zurück.
// Go rundet an der Stelle immer ab z.B. 0,1,1 wäre ja 0,666666666
// 2/3 ergibt in dem Fall 0
func avg(integers ...int) int {
	return 0
}
