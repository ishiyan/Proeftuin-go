The scripts here use matplotlib; they require a Python installation with the
full numeric stack (Numpy, Matplotlib) including Seaborn (for prettier plots).
