The tests are meant to run complete BF programs. Every test case in
``testcases/`` ends with ``.bf`` and has a corresponding ``.test`` file, which
specifies (in JSON format) the test parameters.
