All the Python code in this folder was tested with Python 3.5
