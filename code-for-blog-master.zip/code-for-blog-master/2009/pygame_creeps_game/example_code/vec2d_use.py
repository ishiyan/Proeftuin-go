from vec2d import vec2d


v = vec2d(-1, 1)
print v.angle
