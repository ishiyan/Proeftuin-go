To run the game, install pygame (``pip install pygame``) and run:

.. sourcecode:: text

  $ python creeps.py

