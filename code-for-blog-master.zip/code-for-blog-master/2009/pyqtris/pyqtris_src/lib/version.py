pyqtris_version = "1.01"

