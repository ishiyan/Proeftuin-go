//go:generate samplegentool arg1 arg2 arg3 arg4
package mymod

func AnotherFunc() string {
	return "mymod.AnotherFunc"
}
