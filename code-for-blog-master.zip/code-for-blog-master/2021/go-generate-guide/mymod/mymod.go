package mymod

//go:generate samplegentool arg1 arg2 -flag

func MyFunc() string {
	return "mymod.MyFunc"
}
