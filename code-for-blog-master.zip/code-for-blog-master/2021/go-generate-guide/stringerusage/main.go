package main

import (
	"fmt"

	"stringerusage.com/float"
)

func main() {
	rm := float.AwayFromZero
	fmt.Println(rm)
}
