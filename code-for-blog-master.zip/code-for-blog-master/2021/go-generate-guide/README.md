`mymod` is a sample module which exercises several modes of invoking `go
generate`.

`samplegentool` is a tool that's used in `go generate` directives and emits some
debugging information.
