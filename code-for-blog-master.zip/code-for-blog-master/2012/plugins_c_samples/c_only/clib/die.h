//
// clib/die.h: The "die" convenience function
// 
// Eli Bendersky (eliben@gmail.com)
// This code is in the public domain
//
#ifndef DIE_H
#define DIE_H

void die(char* fmt, ...);

#endif /* DIE_H */

