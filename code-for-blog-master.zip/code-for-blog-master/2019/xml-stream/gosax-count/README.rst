There are two separate commands in this directory, they should be built
separately:

.. sourcecode:: text

	$ go build gosax-count.go
	$ go build gosax-count-simple.go
