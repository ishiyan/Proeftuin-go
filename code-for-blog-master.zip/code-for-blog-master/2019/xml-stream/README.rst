Each file in this directory is a single-file program that expects an XML file
name as its first and only argument.

For the C sample in ``c-libxmlsax-count``, ``cd`` into the directory and run
``make`` to compile.

``gosax-count`` is in its own directory since it uses Go modules to import
a third-party package.

