First run ``make``, then ``go build`` and execute ``./example``. After
``make``, you can also run ``go test``.

Alternatively, run with ``go run``:

.. sourcecode:: text

    $ go run main.go cfuncs.go

