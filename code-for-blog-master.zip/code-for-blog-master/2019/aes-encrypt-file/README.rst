To create a file with random data:

.. sourcecode:: text

	$ dd if=/dev/urandom of=myfile bs=16 count=1000
