The ``sql`` directory is code for the sample using ``database/sql``.

The ``gorm`` directory is code for the sample using ``gorm``.
