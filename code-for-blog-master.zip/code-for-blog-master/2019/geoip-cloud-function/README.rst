To deploy:

.. sourcecode:: text

    $ gcloud functions deploy geoip --entry-point GeoIP --runtime go111 --trigger-http
