For a sample run:

    $ python3 main.py

To run all the unit tests:

    $ python3 -m unittest

This code was tested with Python 3.6, and is expected to work with all later
versions of Python.
