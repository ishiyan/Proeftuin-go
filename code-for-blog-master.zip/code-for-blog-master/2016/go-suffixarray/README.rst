From inside ``src``:

.. sourcecode:: text

    $ go run using_suffixarray.go
    $ go test
    $ go test -bench=.
