; Eli Bendersky [http://eli.thegreenplace.net]
; This code is in the public domain.
(ns multi.core
  (gen-class))
