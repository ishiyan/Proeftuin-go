All code lives in the 'multi' project, in different namespaces per-part.
