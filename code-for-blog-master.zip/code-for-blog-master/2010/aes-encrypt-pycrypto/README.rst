This is a port of the code at
https://eli.thegreenplace.net/2010/06/25/aes-encryption-of-files-in-python-with-pycrypto
to Python 3.x

Tested in a virtualenv created by Python 3.6 with ``pycrypto`` installed from
PyPI.
