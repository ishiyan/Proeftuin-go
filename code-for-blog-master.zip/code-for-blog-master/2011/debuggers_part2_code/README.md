These code samples accompany the original blog post and work in 32-bit mode
Linux.

For a 64-bit port, see the x64/ subdirectory, contributed by Github user
@cheng-chang in https://github.com/eliben/code-for-blog/pull/16
