What we have here:

- qt4reactor.py: 
    A version of qt4reactor I found somewhere online that works
    for me. I didn't modify it.
- qt4reactor.LICENSE: 
    The (unmodified) license of qt4reactor
- twistedclient.py: 
    A class for a simple socket client with Twisted
- sampleguiclient_twisted.py: 
    Sample PyQt GUI that uses twistedclient.py for socket I/O
- test_server.py:
    Basic server for testing the client


Eli Bendersky (eliben@gmail.com)
This code is in the public domain
